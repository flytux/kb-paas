# Common definitions for the tests that are run on cloud
# VMs rather than Semaphore VMs

batches=(k8s-test)
