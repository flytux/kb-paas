# About

This is **not a supported helm chart for installing Calico**. 

If you would like to install Calico via helm, instead see [the supported Calico Helm chart](../tigera-operator).

The templates in this directory are used for generating the contents of the [manifests/](../../manifests) directory, and are not intended
to be used directly as a Helm chart for installing Calico.
