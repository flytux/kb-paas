# Calico authors

This file is auto-generated based on contribution records reported
by GitHub for the core repositories within the projectcalico/ organization. It is ordered alphabetically.

| Name   | Email  |
|--------|--------|
| Aalaesar                                 | aalaesar@gmail.com  |
| Aaron Roydhouse                          | aaron@roydhouse.com  |
| Abhijeet Kasurde                         | akasurde@redhat.com  |
| Abhinav Dahiya                           | abhinav.dahiya@coreos.com  |
| Abhishek Jaisingh                        | abhi2254015@gmail.com  |
| Adam Hoheisel                            | adam.hoheisel99@gmail.com  |
| Adam Leskis                              | leskis@gmail.com  |
| Adam Szecówka                            | adam.szecowka@sap.com  |
| ahrkrak                                  | andrew.randall@gmail.com  |
| Alan                                     | zg.zhu@daocloud.io  |
| Alban Crequy                             | alban@kinvolk.io  |
| Albert Vaca                              | albertvaka@gmail.com  |
| Alejo Carballude                         | alejocarballude@gmail.com  |
| Aleksandr Didenko                        | adidenko@mirantis.com  |
| Aleksandr Dubinsky                       | almson@users.noreply.github.com  |
| Alessandro Rossi                         | 4215912+kubealex@users.noreply.github.com  |
| Alex Altair                              | alexanderaltair@gmail.com  |
| Alex Chan                                | github@alexwlchan.fastmail.co.uk  |
| Alex Hersh                               | alexander.hersh@metaswitch.com  |
| Alex Nauda                               | alex@alexnauda.com  |
| Alex O Regan                             | alexsoregan@gmail.com  |
| Alex Pollitt                             | lxpollitt@users.noreply.github.com  |
| Alex Rowley                              | rowleyaj@gmail.com  |
| Alexander Brand                          | alexbrand09@gmail.com  |
| Alexander Gama Espinosa                  | algamaes@microsoft.com  |
| Alexander Golovko                        | alexandro@ankalagon.ru  |
| Alexander Saprykin                       | asaprykin@mirantis.com  |
| Alexander Varshavsky                     | alex.varshavsky@tigera.io  |
| Alexey Magdich                           | itechart.aliaksei.mahdzich@tigera.io  |
| Alexey Makhov                            | makhov.alex@gmail.com  |
| Alexey Medvedchikov                      | alexey.medvedchikov@gmail.com  |
| alexeymagdich-tigera                     | 56426143+alexeymagdich-tigera@users.noreply.github.com  |
| alexhersh                                | hersh.a@husky.neu.edu  |
| Alina Militaru                           | alina@tigera.io  |
| Aloys Augustin                           | aloaugus@cisco.com  |
| Aloÿs                                    | aloys.augustin@polytechnique.org  |
| Amim Knabben                             | amim.knabben@gmail.com  |
| amq                                      | amq@users.noreply.github.com  |
| Anatoly Popov                            | aensidhe@users.noreply.github.com  |
| Anders Janmyr                            | anders@janmyr.com  |
| Andreas Jaeger                           | aj@suse.com  |
| Andrei Nistor                            | andrei_nistor@smart-x.net  |
| Andrew Donald Kennedy                    | andrew.international@gmail.com  |
| Andrew Gaffney                           | andrew@agaffney.org  |
| Andy Randall                             | andy@tigera.io  |
| Anthony ARNAUD                           | aarnaud@eidosmontreal.com  |
| Anthony BESCOND                          | anthony.bescond@kiln.fi  |
| Anthony T                                | 25327116+anthonytwh@users.noreply.github.com  |
| Anton Antonov                            | anton.synd.antonov@gmail.com  |
| Anton Klokau                             | anton.klokau@gmail.com  |
| anton-klokau                             | 54411589+anton-klokau@users.noreply.github.com  |
| Antony Guinard                           | antony@tigera.io  |
| Aram Alipoor                             | aram.alipoor@gmail.com  |
| arikachen                                | eaglesora@gmail.com  |
| Armon Dadgar                             | armon.dadgar@gmail.com  |
| Artem Panchenko                          | apanchenko@mirantis.com  |
| Artem Roma                               | aroma@mirantis.com  |
| Artem Rymarchik                          | artemrymarchik@gmail.com  |
| Artyom Rymarchik                         | artsiom.rymarchyk@itechart-group.com  |
| Arundhati Surpur                         | arundhati@nectechnologies.in  |
| Ashley Reese                             | ashley@victorianfox.com  |
| asincu                                   | alinamilitaru@Alinas-MacBook-Pro.local  |
| Atkins                                   | atkinschang@gmail.com  |
| Avi Deitcher                             | avi@deitcher.net  |
| Ayoub Elhamdani                          | a.elhamdani90@gmail.com  |
| Barbara McKercher                        | barbara@tigera.io  |
| bartek-lopatka                           | 54111388+bartek-lopatka@users.noreply.github.com  |
| Bassam Tabbara                           | bassam@symform.com  |
| Behnam Shobiri                           | behnam.shobeiri@gmail.com  |
| Behnam-Shobiri                           | Behnam.shobeiri@gmail.com  |
| Ben Schwartz                             | benschw@gmail.com  |
| Benjamin                                 | info@diffus.org  |
| Benjamin S. Allen                        | bsallen@alcf.anl.gov  |
| Bertrand Lallau                          | bertrand.lallau@gmail.com  |
| Bill Hathaway                            | bill.hathaway@gmail.com  |
| Bill Maxwell                             | bill@rancher.com  |
| Billie Cleek                             | bcleek@monsooncommerce.com  |
| bingshen.wbs                             | bingshen.wbs@alibaba-inc.com  |
| bjhaid                                   | abejideayodele@gmail.com  |
| Blake Covarrubias                        | blake.covarrubias@gmail.com  |
| Blucher                                  | yfg44fox@126.com  |
| bmckercher123                            | 48458529+bmckercher123@users.noreply.github.com  |
| Bogdan Dobrelya                          | bdobrelia@mirantis.com  |
| Brad Beam                                | brad.beam@b-rad.info  |
| Brad Behle                               | behle@us.ibm.com  |
| Brendan Creane                           | brendan@tigera.io  |
| Brian Ketelsen                           | bketelsen@gmail.com  |
| Brian Kim                                | brian@tigera.io  |
| Brian McMahon                            | brianmcmahon135@gmail.com  |
| briansan                                 | bkimstunnaboss@gmail.com  |
| Brook-Roberts                            | brook.roberts@metaswitch.com  |
| Bryan Reese                              | bryan.mreese@gmail.com  |
| Cao Shufeng                              | caosf.fnst@cn.fujitsu.com  |
| Cao Xuan Hoang                           | hoangcx@vn.fujitsu.com  |
| Carlos Alberto                           | euprogramador@gmail.com  |
| Casey D                                  | casey.davenport@metaswitch.com  |
| Casey Davenport                          | davenport.cas@gmail.com  |
| Cezar Sa Espinola                        | cezarsa@gmail.com  |
| Chakravarthy Gopi                        | cgopi@us.ibm.com  |
| Chance Zibolski                          | chance.zibolski@gmail.com  |
| Chen Donghui                             | chendh521@gmail.com  |
| Chengwei Yang                            | yangchengwei@qiyi.com  |
| chenqijun                                | chenqijun@corp.netease.com  |
| Chris Armstrong                          | chris@opdemand.com  |
| Chris Church                             | chris.church@gmail.com  |
| Chris Hoge                               | chris@hogepodge.com  |
| Chris McNabb                             | raizyr@gmail.com  |
| Chris Tomkins                            | chris.tomkins@tigera.io  |
| Christian Klauser                        | christianklauser@outlook.com  |
| Christian Simon                          | simon@swine.de  |
| Christopher                              | chris.tauchen@tigera.io  |
| Christopher Grim                         | christopher.grim@gmail.com  |
| Christopher LIJLENSTOLPE                 | github@cdl.asgaard.org  |
| Christopher LILJENSTOLPE                 | cdl@asgaard.org  |
| cinience                                 | cinience@qq.com  |
| Ciprian Hacman                           | ciprian@hakman.dev  |
| Clement Laforet                          | sheepkiller@cotds.org  |
| Cody McCain                              | cody@tigera.io  |
| Cookie                                   | luckymrwang@163.com  |
| Cory Benfield                            | lukasaoz@gmail.com  |
| crandl201                                | christopher_randles@cable.comcast.com  |
| Cristian Vrabie                          | cristian.vrabie@gmail.com  |
| Cyclinder                                | qifeng.guo@daocloud.io  |
| Dalton Hubble                            | dghubble@gmail.com  |
| Dan                                      | djosborne@users.noreply.github.com  |
| Dan (Turk)                               | dan@projectcalico.org  |
| Dan Bond                                 | pm@danbond.io  |
| Dan O'Brien                              | dobrien.nj@gmail.com  |
| Dan Osborne                              | djosborne10@gmail.com  |
| Daniel Hoherd                            | daniel.hoherd@gmail.com  |
| Daniel Megyesi                           | daniel.megyesi@liligo.com  |
| Dario Nieuwenhuis                        | dirbaio@dirbaio.net  |
| Darren Chin                              | dc@darrench.in  |
| Dave Hay                                 | david_hay@uk.ibm.com  |
| Dave Langridge                           | dave@calico.com  |
| David Haupt                              | dhaupt@redhat.com  |
| David Igou                               | igou.david@gmail.com  |
| David J. Wilder                          | wilder@us.ibm.com  |
| David Tesar                              | david.tesar@microsoft.com  |
| Denis Iskandarov                         | d.iskandarov@gmail.com  |
| depay                                    | depay19@163.com  |
| derek mcquay                             | derek@tigera.io  |
| Derk Muenchhausen                        | derk@muenchhausen.de  |
| Didier Durand                            | durand.didier@gmail.com  |
| Dominic DeMarco                          | ddemarc@us.ibm.com  |
| Doug Collier                             | doug@tigera.io  |
| Doug Davis                               | duglin@users.noreply.github.com  |
| Doug Hellmann                            | doug@doughellmann.com  |
| Doug Wiegley                             | dwiegley@salesforce.com  |
| Dries Harnie                             | dries+github@harnie.be  |
| du                                       | du@njtech.edu.cn  |
| Duan Jiong                               | djduanjiong@gmail.com  |
| Duong Ha-Quang                           | duonghq@vn.fujitsu.com  |
| Dylan Pindur                             | dylanpindur@gmail.com  |
| Ed Harrison                              | eepyaich@users.noreply.github.com  |
| Edbert                                   | ecandra@protonmail.com  |
| Elson Rodriguez                          | elson.rodriguez@gmail.com  |
| emanic                                   | emily@tigera.io  |
| Emma Gordon                              | emma@projectcalico.org  |
| EmmEff                                   | mikef17@gmail.com  |
| Eran Reshef                              | eran.reshef@arm.com  |
| Eric Anderson                            | anderson@stackengine.com  |
| Eric Barch                               | ericb@ericbarch.com  |
| Eric Hoffmann                            | 31017077+2ffs2nns@users.noreply.github.com  |
| Erik Stidham                             | estidham@gmail.com  |
| Ernest Wong                              | chuwon@microsoft.com  |
| Ernesto Jiménez                         | me@ernesto-jimenez.com  |
| Ethan Chu                                | xychu2008@gmail.com  |
| Eugen Mayer                              | 136934+EugenMayer@users.noreply.github.com  |
| F41gh7                                   | info@fght.net  |
| Fabian Ruff                              | fabian@progra.de  |
| Fahad Arshad                             | fahadaliarshad@gmail.com  |
| fcuello-fudo                             | 51087976+fcuello-fudo@users.noreply.github.com  |
| Feilong Wang                             | flwang@catalyst.net.nz  |
| fen4o                                    | martin.vladev@gmail.com  |
| Fernando Alvarez                         | methadato@gmail.com  |
| Fernando Cainelli                        | fernando.cainelli@gmail.com  |
| Fionera                                  | fionera@fionera.de  |
| Flavio Percoco                           | flaper87@gmail.com  |
| Foivos Filippopoulos                     | foivosfilip@gmail.com  |
| frank                                    | frank@tigera.io  |
| Frank Greco Jr                           | frankgreco@northwesternmutual.com  |
| François PICOT                           | fpicot@users.noreply.github.com  |
| Fredrik Steen                            | stone4x4@gmail.com  |
| freecaykes                               | edbert@tigera.io  |
| frnkdny                                  | frank.danyo@gmail.com  |
| fumihiko kakuma                          | kakuma@valinux.co.jp  |
| Gabriel Monroy                           | gabriel@opdemand.com  |
| Gaurav                                   | 48036489+realgaurav@users.noreply.github.com  |
| Gaurav Khatri                            | gaurav@tigera.io  |
| Gaurav Sinha                             | gaurav.sinha@tigera.io  |
| Gautam K                                 | gautam.nitheesh@gmail.com  |
| gdziwoki                                 | gdziwoki@gmail.com  |
| gengchc2                                 | geng.changcai2@zte.com.cn  |
| Gerard Hickey                            | hickey@kinetic-compute.com  |
| Giancarlo Rubio                          | gianrubio@gmail.com  |
| Gianluca                                 | 52940363+gianlucam76@users.noreply.github.com  |
| Gianluca Mardente                        | gianluca@tigera.io  |
| Gobinath Krishnamoorthy                  | gobinath@tigera.io  |
| Guang Ya Liu                             | gyliu513@gmail.com  |
| Guangming Wang                           | guangming.wang@daocloud.io  |
| Guillaume LECERF                         | glecerf@gmail.com  |
| guirish                                  | guirish  |
| gunboe                                   | guntherboeckmann@gmail.com  |
| Gunjan "Grass-fed Rabbit" Patel          | patelgunjan5@gmail.com  |
| GuyTempleton                             | guy.templeton@skyscanner.net  |
| Hagen Kuehn                              | hagen.kuehn@quater.io  |
| halfcrazy                                | hackzhuyan@gmail.com  |
| Hanamantagoud                            | hanamantagoud.v.kandagal@est.tech  |
| hanamantagoudvk                          | 68010010+hanamantagoudvk@users.noreply.github.com  |
| hedi bouattour                           | hbouatto@cisco.com  |
| Helen Chang                              | c6h3un@gmail.com  |
| Henry Gessau                             | gessau@gmail.com  |
| huang.zhiping                            | huang.zhiping@99cloud.net  |
| Huanle Han                               | hanhuanle@caicloud.io  |
| Hui Kang                                 | kangh@us.ibm.com  |
| Huo Qi Feng                              | huoqif@cn.ibm.com  |
| Iago López Galeiras                      | iago@kinvolk.io  |
| ialidzhikov                              | i.alidjikov@gmail.com  |
| Ian Wienand                              | iwienand@redhat.com  |
| Icarus9913                               | icaruswu66@qq.com  |
| Igor Kapkov                              | igasgeek@me.com  |
| Ihar Hrachyshka                          | ihrachys@redhat.com  |
| ijumps                                   | “bigerjump@gmail.com”  |
| ISHIDA Wataru                            | ishida.wataru@lab.ntt.co.jp  |
| Ivar Larsson                             | ivar@bloglovin.com  |
| IWAMOTO Toshihiro                        | iwamoto@valinux.co.jp  |
| J. Grizzard                              | jgrizzard@box.com  |
| Jack Kleeman                             | jackkleeman@gmail.com  |
| Jacob Hayes                              | jacob.r.hayes@gmail.com  |
| Jade Chunnananda                         | jade.jch@gmail.com  |
| Jak                                      | 44370243+jak-sdk@users.noreply.github.com  |
| James E. Blair                           | jeblair@redhat.com  |
| James Lucktaylor                         | jlucktay@users.noreply.github.com  |
| James Pollard                            | james@leapyear.io  |
| James Sturtevant                         | jsturtevant@gmail.com  |
| Jamie                                    | 91jme@users.noreply.github.com  |
| Jan Brauer                               | jan@jimdo.com  |
| Jan Ivar Beddari                         | code@beddari.net  |
| janonymous                               | janonymous.codevulture@gmail.com  |
| jay vyas                                 | jvyas@vmware.com  |
| Jean-Sebastien Mouret                    | js.mouret@gmail.com  |
| Jeff Schroeder                           | jeffschroeder@computer.org  |
| Jenkins                                  | jenkins@review.openstack.org  |
| Jens Henrik Hertz                        | jens@treatwell.nl  |
| Jesper Dangaard Brouer                   | brouer@redhat.com  |
| Jiawei Huang                             | jiawei@tigera.io  |
| Jimmy McCrory                            | jimmy.mccrory@gmail.com  |
| jinglinax@163.com                        | jinglinax@163.com  |
| jmjoy                                    | 918734043@qq.com  |
| Joanna Solmon                            | joanna.solmon@gmail.com  |
| Joel Bastos                              | kintoandar@users.noreply.github.com  |
| Johan Fleury                             | jfleury+github@arcaik.net  |
| Johannes M. Scheuermann                  | joh.scheuer@gmail.com  |
| Johannes Scheerer                        | johannes.scheerer@sap.com  |
| johanneswuerbach                         | johannes.wuerbach@googlemail.com  |
| John Engelman                            | john.r.engelman@gmail.com  |
| jolestar                                 | jolestar@gmail.com  |
| Jonah Back                               | jonah@jonahback.com  |
| Jonathan Boulle                          | jonathanboulle@gmail.com  |
| Jonathan M. Wilbur                       | jonathan@wilbur.space  |
| Jonathan Palardy                         | jonathan.palardy@gmail.com  |
| Jonathan Sabo                            | jonathan@sabo.io  |
| Jonathan Sokolowski                      | jonathan.sokolowski@gmail.com  |
| jose-bigio                               | jose.bigio@docker.com  |
| Joseph Gu                                | aceralon@outlook.com  |
| Josh Conant                              | deathbeforedishes@gmail.com  |
| Josh Lucas                               | josh.lucas@tigera.io  |
| joshti                                   | 56737865+joshti@users.noreply.github.com  |
| Joshua Allard                            | josh@tigera.io  |
| joshuactm                                | joshua.colvin@ticketmaster.com  |
| Julien Dehee                             | PrFalken@users.noreply.github.com  |
| Jussi Nummelin                           | jussi.nummelin@digia.com  |
| Justin                                   | justin@tigera.io  |
| Justin Burnham                           | justin@jburnham.net  |
| Justin Cattle                            | j@ocado.com  |
| Justin Nauman                            | justin.r.nauman+github@gmail.com  |
| Justin Pacheco                           | jpacheco39@bloomberg.net  |
| Justin Sievenpiper                       | justin@sievenpiper.co  |
| JW Bell                                  | bjwbell@gmail.com  |
| Kamil Madac                              | kamil.madac@gmail.com  |
| Karl Matthias                            | karl.matthias@gonitro.com  |
| Karthik Gaekwad                          | karthik.gaekwad@gmail.com  |
| Karthik Krishnan Ramasubramanian         | mail@karthikkrishnan.me  |
| Kashif Saadat                            | kashifsaadat@gmail.com  |
| Kelsey Hightower                         | kelsey.hightower@gmail.com  |
| Ketan Kulkarni                           | ketkulka@gmail.com  |
| Kevin Benton                             | blak111@gmail.com  |
| Kevin Lynch                              | klynch@gmail.com  |
| Kiran Divekar                            | calsoft.kiran.divekar@tigera.io  |
| Kirill Buev                              | kirill.buev@pm.me  |
| Kris Gambirazzi                          | kris.gambirazzi@transferwise.com  |
| Krzesimir Nowak                          | krzesimir@kinvolk.io  |
| Krzysztof Cieplucha                      | krisiasty@users.noreply.github.com  |
| l1b0k                                    | libokang.dev@gmail.com  |
| Lance Robson                             | lancelot.robson@gmail.com  |
| Lancelot Robson                          | lancelot.robson@metaswitch.com  |
| Lars Ekman                               | lars.g.ekman@est.tech  |
| Laurence Man                             | laurence@tigera.io  |
| Le Hou                                   | houl7@chinaunicom.cn  |
| Lee Briggs                               | lbriggs@apptio.com  |
| Leo Ochoa                                | leo8a@users.noreply.github.com  |
| Li-zhigang                               | li.zhigang3@zte.com.cn  |
| libby kent                               | viskcode@gmail.com  |
| lilintan                                 | lintan.li@easystack.cn  |
| LinYushen                                | linyushen@qiniu.com  |
| lippertmarkus                            | lippertmarkus@gmx.de  |
| LittleBoy18                              | 2283985296@qq.com  |
| liubog2008                               | liubog2008@gmail.com  |
| Liz Rice                                 | liz@lizrice.com  |
| llr                                      | nightmeng@gmail.com  |
| Logan Davis                              | 38335829+logand22@users.noreply.github.com  |
| Logan V                                  | logan2211@gmail.com  |
| lou-lan                                  | loulan@loulan.me  |
| Luiz Filho                               | luizbafilho@gmail.com  |
| Luke Mino-Altherr                        | luke.mino-altherr@metaswitch.com  |
| luobily                                  | luobily@gmail.com  |
| Luthfi Anandra                           | luthfi.anandra@gmail.com  |
| Lv Jiawei                                | lvjiawei@cmss.chinamobile.com  |
| maao                                     | maao@cmss.chinamobile.com  |
| Manjunath A Kumatagi                     | mkumatag@in.ibm.com  |
| Manuel Buil                              | mbuil@suse.com  |
| Marga Millet                             | marga.sfo@gmail.com  |
| Marius Grigaitis                         | marius.grigaitis@home24.de  |
| Mark Fermor                              | markfermor@holidayextras.com  |
| Mark Petrovic                            | mspetrovic@gmail.com  |
| markruler                                | csu0414@gmail.com  |
| Marlin Cremers                           | marlinc@marlinc.nl  |
| Marshall Ford                            | inbox@marshallford.me  |
| Martijn Koster                           | mak-github@greenhills.co.uk  |
| Martin Evgeniev                          | suizman@users.noreply.github.com  |
| marvin-tigera                            | marvin-tigera@users.noreply.github.com  |
| Mat Meredith                             | matthew.meredith@metaswitch.net  |
| Mateusz Gozdek                           | mgozdek@microsoft.com  |
| Mathias Lafeldt                          | mathias.lafeldt@gmail.com  |
| Matt                                     | matt@projectcalico.org  |
| Matt Boersma                             | matt@opdemand.com  |
| Matt Dupre                               | matthewdupre@users.noreply.github.com  |
| Matt Kelly                               | Matthew.Joseph.Kelly@gmail.com  |
| Matt Leung                               | mleung975@gmail.com  |
| Matthew                                  | mfisher@engineyard.com  |
| Matthew Fenwick                          | mfenwick100@gmail.com  |
| Matthew Fisher                           | matthewf@opdemand.com  |
| Max Kudosh                               | max_kudosh@hotmail.com  |
| Max S                                    | maxstr@users.noreply.github.com  |
| Max Stritzinger                          | mstritzinger@bloomberg.net  |
| Maxim Ivanov                             | ivanov.maxim@gmail.com  |
| Maximilian Bischoff                      | maximilian.bischoff@inovex.de  |
| Mayo                                     | mayocream39@yahoo.co.jp  |
| Mazdak Nasab                             | mazdak@tigera.io  |
| mchtech                                  | michu_an@126.com  |
| meeee                                    | michael+git@frister.net  |
| meijin                                   | meijin@tiduyun.com  |
| melissaml                                | ma.lei@99cloud.net  |
| Michael Dong                             | michael.dong@vrviu.com  |
| Michael Stowe                            | me@mikestowe.com  |
| Michael Vierling                         | michael@tigera.io  |
| Micheal Waltz                            | ecliptik@gmail.com  |
| Mikalai Kastsevich                       | kostevich-kolya@mail.ru  |
| Mike Kostersitz                          | mikek@microsoft.com  |
| Mike Palmer                              | mike@mikepalmer.net  |
| Mike Scherbakov                          | mihgen@gmail.com  |
| Mike Spreitzer                           | mspreitz@us.ibm.com  |
| Mike Stephen                             | mike.stephen@tigera.io  |
| Mike Stowe                               | mikestowe@Mikes-MBP.sfo.tigera.io  |
| mikev                                    | mvierling@gmail.com  |
| Miouge1                                  | Miouge1@users.noreply.github.com  |
| ml                                       | 6209465+ml-@users.noreply.github.com  |
| mlbarrow                                 | michael@barrow.me  |
| MofeLee                                  | mofe@me.com  |
| Mohamed                                  | mohamed.elzarei@motius.de  |
| Molnigt                                  | jan.munkhammar@safespring.com  |
| Monty Taylor                             | mordred@inaugust.com  |
| Mridul Gain                              | mridulgain@gmail.com  |
| Muhammad Saghir                          | msagheer92@gmail.com  |
| Muhammet Arslan                          | muhammet.arsln@gmail.com  |
| Murali Paluru                            | leodotcloud@gmail.com  |
| Mészáros Mihály                          | misi@majd.eu  |
| Nate Taylor                              | ntaylor1781@gmail.com  |
| Nathan Fritz                             | fritzy@netflint.net  |
| Nathan Skrzypczak                        | nathan.skrzypczak@gmail.com  |
| Nathan Wouda                             | nwouda@users.noreply.github.com  |
| Neil Jerram                              | nj@metaswitch.com  |
| Nic Doye                                 | nic@worldofnic.org  |
| Nick Bartos                              | nick@pistoncloud.com  |
| Nick Wood                                | nwood@microsoft.com  |
| Nikkau                                   | nikkau@nikkau.net  |
| Nirman Narang                            | narang@us.ibm.com  |
| njuptlzf                                 | njuptlzf@163.com  |
| Noah Treuhaft                            | noah.treuhaft@docker.com  |
| nohajc                                   | nohajc@gmail.com  |
| nuczzz                                   | 33566732+nuczzz@users.noreply.github.com  |
| nuxeric                                  | 48699932+nuxeric@users.noreply.github.com  |
| Oded Lazar                               | odedlaz@gmail.com  |
| oldtree2k                                | oldtree2k@users.noreply.github.com  |
| Olivier Bourdon                          | obourdon@mirantis.com  |
| Onong Tayeng                             | onong.tayeng@gmail.com  |
| OpenDev Sysadmins                        | openstack-infra@lists.openstack.org  |
| Otto Sulin                               | otto.sulin@gmail.com  |
| Owen Tuz                                 | owen@segfault.re  |
| pasanw                                   | pasanweerasinghe@gmail.com  |
| Patrick Marques                          | pmarques@users.noreply.github.com  |
| Patrik Lundin                            | patrik@sigterm.se  |
| Paul Tiplady                             | symmetricone@gmail.com  |
| Pavel Khusainov                          | pkhusainov@mz.com  |
| Pedro Coutinho                           | pedro@tigera.io  |
| Penkey Suresh                            | penkeysuresh@users.noreply.github.com  |
| penkeysuresh                             | penkeysuresh@gmail.com  |
| peter                                    | peterkellyonline@gmail.com  |
| Peter Kelly                              | 659713+petercork@users.noreply.github.com  |
| Peter Nordquist                          | peter.nordquist@pnnl.gov  |
| Peter Salanki                            | peter@salanki.st  |
| Peter White                              | peter.white@metaswitch.com  |
| Phil Kates                               | me@philkates.com  |
| Philip Southam                           | philip.southam@jpl.nasa.gov  |
| Phu Kieu                                 | pkieu@jpl.nasa.gov  |
| Pierre Grimaud                           | grimaud.pierre@gmail.com  |
| Pike.SZ.fish                             | pikeszfish@gmail.com  |
| Prayag Verma                             | prayag.verma@gmail.com  |
| Pushkar Joglekar                         | pjoglekar@vmware.com  |
| PythonSyntax1                            | 51872355+PythonSyntax1@users.noreply.github.com  |
| Qiu Yu                                   | qiuyu@ebaysf.com  |
| Rafael                                   | rafael@tigera.io  |
| Rafal Borczuch                           | rafalq.b+github@gmail.com  |
| Rafe Colton                              | r.colton@modcloth.com  |
| Rahul Krishna Upadhyaya                  | rakrup@gmail.com  |
| rao yunkun                               | yunkunrao@gmail.com  |
| Renan Gonçalves                          | renan.saddam@gmail.com  |
| Rene Dekker                              | rene@tigera.io  |
| Rene Kaufmann                            | kaufmann.r@gmail.com  |
| Reza R                                   | 54559947+frozenprocess@users.noreply.github.com  |
| Ricardo Katz                             | rikatz@users.noreply.github.com  |
| Ricardo Pchevuzinske Katz                | ricardo.katz@serpro.gov.br  |
| Richard Kovacs                           | kovacsricsi@gmail.com  |
| Richard Laughlin                         | richardwlaughlin@gmail.com  |
| Richard Marshall                         | richard.marshall@ask.com  |
| Ripta Pasay                              | ripta@users.noreply.github.com  |
| Rob Brockbank                            | robbrockbank@gmail.com  |
| Rob Terhaar                              | robbyt@robbyt.net  |
| Robert Brockbank                         | rob.brockbank@metswitch.com  |
| Robert Coleman                           | github@robert.net.nz  |
| Roberto Alcantara                        | roberto@eletronica.org  |
| Robin Müller                             | robin.mueller@outlook.de  |
| Rodrigo Barbieri                         | rodrigo.barbieri2010@gmail.com  |
| Roman Danko                              | elcomtik@users.noreply.github.com  |
| Roman Sokolkov                           | roman@giantswarm.io  |
| Ronnie P. Thomas                         | rpthms@users.noreply.github.com  |
| Roshani Rathi                            | rrroshani227@gmail.com  |
| roshanirathi                             | 42164609+roshanirathi@users.noreply.github.com  |
| Rui Chen                                 | rchen@meetup.com  |
| rushtehrani                              | r@inven.io  |
| Rustam Zagirov                           | stammru@gmail.com  |
| Ryan Zhang                               | ryan.zhang@docker.com  |
| rymarchikbot                             | 43807162+rymarchikbot@users.noreply.github.com  |
| Saeid Askari                             | askari.saeed@gmail.com  |
| Satish Matti                             | smatti@google.com  |
| Satoru Takeuchi                          | sat@cybozu.co.jp  |
| Saurabh Mohan                            | saurabh@tigera.io  |
| Sean Kilgore                             | logikal@users.noreply.github.com  |
| Sedef                                    | ssavas@vmware.com  |
| Semaphore Automatic Update               | tom@tigera.io  |
| Sergey Kulanov                           | skulanov@mirantis.com  |
| Sergey Melnik                            | sergey.melnik@commercetools.de  |
| Seth                                     | sethpmccombs@gmail.com  |
| Seth Malaki                              | seth@tigera.io  |
| Shatrugna Sadhu                          | shatrugna.sadhu@gmail.com  |
| Shaun Crampton                           | smc@metaswitch.com  |
| shouheng.lei                             | shouheng.lei@easystack.cn  |
| Simão Reis                              | smnrsti@gmail.com  |
| SONG JIANG                               | song@tigera.io  |
| SongmingYan                              | yan.songming@zte.com.cn  |
| spdfnet                                  | 32593931+spdfnet@users.noreply.github.com  |
| Spike Curtis                             | spike@tigera.io  |
| squ94wk                                  | squ94wk@googlemail.com  |
| sridhar                                  | sridhar@tigera.io  |
| sridhartigera                            | 63839878+sridhartigera@users.noreply.github.com  |
| Sriram Yagnaraman                        | sriram.yagnaraman@est.tech  |
| Stanislav Yotov                          | 29090864+svyotov@users.noreply.github.com  |
| Stanislav-Galchynski                     | Stanislav.Galchynski@itechart-group.com  |
| Stefan Breunig                           | stefan.breunig@xing.com  |
| Stefan Bueringer                         | sbueringer@gmail.com  |
| Stephen Schlie                           | schlie@tigera.io  |
| Steve Gao                                | steve@tigera.io  |
| Stéphane Cottin                          | stephane.cottin@vixns.com  |
| Suraiya Hameed                           | 22776421+Suraiya-Hameed@users.noreply.github.com  |
| Suraj Narwade                            | surajnarwade353@gmail.com  |
| svInfra17                                | vinayak@infracloud.io  |
| Szymon Pyżalski                          | spyzalski@mirantis.com  |
| TAKAHASHI Shuuji                         | shuuji3@gmail.com  |
| Tamal Saha                               | tamal@appscode.com  |
| Tathagata Chowdhury                      | calsoft.tathagata.chowdhury@tigera.io  |
| tathagatachowdhury                       | tathagata.chowdhury@calsoftinc.com  |
| Teller-Ulam                              | 2749404+Teller-Ulam@users.noreply.github.com  |
| Thijs Scheepers                          | tscheepers@users.noreply.github.com  |
| Thilo Fromm                              | thilo@kinvolk.io  |
| Thomas Lohner                            | tl@scale.sc  |
| Tim Bart                                 | tim@pims.me  |
| Tim Briggs                               | timothydbriggs@gmail.com  |
| Timo Beckers                             | timo.beckers@klarrio.com  |
| Todd Nine                                | tnine@apigee.com  |
| Tom Denham                               | tom@tomdee.co.uk  |
| Tom Pointon                              | tom@teepeestudios.net  |
| Tomas Hruby                              | tomas@tigera.io  |
| Tomas Mazak                              | tomas@valec.net  |
| Tommaso Pozzetti                         | tommypozzetti@hotmail.it  |
| tonic                                    | tonicbupt@gmail.com  |
| ToroNZ                                   | tomasmaggio@gmail.com  |
| Trapier Marshall                         | trapier.marshall@docker.com  |
| Trevor Tao                               | trevor.tao@arm.com  |
| Trond Hasle Amundsen                     | t.h.amundsen@usit.uio.no  |
| turekt                                   | 32360115+turekt@users.noreply.github.com  |
| tuti                                     | tuti@tigera.io  |
| Tyler Stachecki                          | tstachecki@bloomberg.net  |
| Uwe Dauernheim                           | uwe@dauernheim.net  |
| Uwe Krueger                              | uwe.krueger@sap.com  |
| vagrant                                  | vagrant@mesos.vm  |
| Valentin Ouvrard                         | valentin.ouvrard@nautile.sarl  |
| Viacheslav Vasilyev                      | avoidik@gmail.com  |
| Vieri                                    | 15050873171@163.com  |
| Vincent Schwarzer                        | vincent.schwarzer@yahoo.de  |
| Vivek Thrivikraman                       | vivek.thrivikraman@est.tech  |
| wangwengang                              | wangwengang@inspur.com  |
| Wei Kin Huang                            | weikin.huang04@gmail.com  |
| Wei.ZHAO                                 | zhaowei@qiyi.com  |
| weizhouBlue                              | 45163302+weizhouBlue@users.noreply.github.com  |
| Wietse Muizelaar                         | wmuizelaar@bol.com  |
| Will Rouesnel                            | w.rouesnel@gmail.com  |
| Wouter Schoot                            | wouter@schoot.org  |
| wuranbo                                  | wuranbo@gmail.com  |
| wwgfhf                                   | 51694849+wwgfhf@users.noreply.github.com  |
| Xiang Dai                                | 764524258@qq.com  |
| Xiang Liu                                | lx1036@126.com  |
| xieyanker                                | xjsisnice@gmail.com  |
| Xin He                                   | he_xinworld@126.com  |
| YAMAMOTO Takashi                         | yamamoto@midokura.com  |
| Yan Zhu                                  | yanzhu@alauda.io  |
| yang59324                                | yang59324@163.com  |
| yanyan8566                               | 62531742+yanyan8566@users.noreply.github.com  |
| yassan                                   | yassan0627@gmail.com  |
| Yecheng Fu                               | cofyc.jackson@gmail.com  |
| Yi He                                    | yi.he@arm.com  |
| Yi Tao                                   | yitao@qiniu.com  |
| ymyang                                   | yangym9@lenovo.com  |
| Yongkun Gui                              | ygui@google.com  |
| Yuji Azama                               | yuji.azama@gmail.com  |
| zealic                                   | zealic@gmail.com  |
| zhangjie                                 | zhangjie0619@yeah.net  |
| zhouxinyong                              | zhouxinyong@inspur.com  |
| Zopanix                                  | zopanix@gmail.com  |
| Zuul                                     | zuul@review.openstack.org  |
