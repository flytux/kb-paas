# CNI Configuration

The configuration guide has moved to the [main Calico documentation](http://docs.projectcalico.org/master/reference/cni-plugin/configuration).
