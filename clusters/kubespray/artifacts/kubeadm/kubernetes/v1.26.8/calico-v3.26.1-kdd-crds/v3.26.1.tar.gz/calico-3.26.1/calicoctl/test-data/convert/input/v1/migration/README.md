The test data here is to be used when testing out the offline migration from
v1 to v3.
